from django.shortcuts import render

def index(request):
    return render(request, 'book_app/index.html')

def book(request):
    return render(request, 'book_app/books.html')


def author(request):
    return render(request, 'book_app/authors.html')


def shelf(request):
    return render(request, 'book_app/shelves.html')