from django.urls import path
from book_app import views

urlpatterns = [
    path('books/', views.book, name='book_name'),
    path('authors/', views.author, name='author_name'),
    path('shelves/', views.shelf, name='shelf_name'),
]