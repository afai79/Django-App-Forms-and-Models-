from django.shortcuts import render
from book_app.forms import BookName, AuthorName, ShelfName

def index(request):
    return render(request, 'book_app/index.html')

def book_name(request):
    book = BookName()

    if request.method=='POST':
        form = BookName(request.POST)
        if form.is_valid():
            form.save(commit=True)
            return index(request)
        else:
                print('ERROR FORM INVALID')

    return render(request, 'book_app/books.html', {'book': book})

def author_name(request):
    author=AuthorName()

    if request.method=='POST':
        form = AuthorName(request.POST)
        if form.is_valid():
            form.save(commit=True)
            return index(request)
        else:
                print('ERROR FORM INVALID')

    return render(request, 'book_app/authors.html', {'author': author})

def shelf_name(request):
    shelf=ShelfName()

    if request.method=='POST':
        form = ShelfName(request.POST)
        if form.is_valid():
            form.save(commit=True)
            return index(request)
        else:
                print('ERROR FORM INVALID')

    return render(request, 'book_app/shelves.html', {'shelf': shelf})