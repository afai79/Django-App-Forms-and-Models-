from django import forms
from book_app.models import Book, Author, Shelf

class BookName(forms.ModelForm):
    class Meta():
        model = Book
        fields = '__all__'

class AuthorName(forms.ModelForm):
    class Meta():
        model = Author
        fields = '__all__'

class ShelfName(forms.ModelForm):
    class Meta():
        model = Shelf
        fields = '__all__'