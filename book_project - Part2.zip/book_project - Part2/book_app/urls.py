from django.urls import path
from book_app import views

urlpatterns = [
    path('books/', views.book_name, name='book_name'),
    path('authors/', views.author_name, name='author_name'),
    path('shelves/', views.shelf_name, name='shelf_name'),
]