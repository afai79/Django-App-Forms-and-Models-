from django.contrib import admin
from form_app.models import User

# Register your models here.

admin.site.register(User)