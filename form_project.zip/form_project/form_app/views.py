from django.shortcuts import render
from .forms import FormName

# Create your views here.

def index(request):
    my_dir={'insert_me' : "Hi I'm using Django app"}
    return render(request, 'form_app/index.html', context=my_dir)


def form_name_view(request):
    form = FormName()

    if request.method=='POST':
        form = FormName(request.POST)
        if form.is_valid():
            form.save(commit=True)
            return index(request)
        else:
            print('ERROR FORM INVALID')

    return render(request, 'form_app/form_page.html', {'form': form})
    