from django.urls import path
from form_app import views

urlpatterns = [
 #   path('', views.index, name = 'index'),
    path('', views.form_name_view, name='form_name')
]