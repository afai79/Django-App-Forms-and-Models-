from attr import fields
from django import forms
from .models import User

class FormName(forms.ModelForm):
    class Meta():
        model = User
        fields = '__all__'