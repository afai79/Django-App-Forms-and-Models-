from tkinter.messagebox import YES
from attr import fields
from django import forms
from form_app.models import User

class FormName(forms.ModelForm):
    class Meta():
       model = User
       fields='__all__'


#   firstname = forms.CharField()
#   lastname = forms.CharField()
#   email = forms.EmailField()